import { motion } from 'framer-motion';
import { User, Bell, Shield, Palette, Globe, Database, Key, LogOut, ChevronRight, Zap } from 'lucide-react';

const sections = [
  {
    id: 'profile',
    title: 'Profile Settings',
    icon: User,
    color: '#42a5f5',
    settings: [
      { label: 'Display Name', value: 'N. Balakrishna', type: 'text' },
      { label: 'Constituency', value: 'Guntur, Andhra Pradesh', type: 'text' },
      { label: 'Party', value: 'TDP', type: 'text' },
      { label: 'Email', value: 'mp.guntur@sansad.nic.in', type: 'email' },
      { label: 'Phone', value: '+91 86400 00000', type: 'text' },
    ],
  },
  {
    id: 'notifications',
    title: 'Notifications',
    icon: Bell,
    color: '#ffa726',
    settings: [
      { label: 'Urgent Grievances Alert', value: true, type: 'toggle' },
      { label: 'New Media Mentions', value: true, type: 'toggle' },
      { label: 'Event Reminders', value: true, type: 'toggle' },
      { label: 'Finance Updates', value: false, type: 'toggle' },
      { label: 'Project Milestones', value: true, type: 'toggle' },
    ],
  },
  {
    id: 'security',
    title: 'Security',
    icon: Shield,
    color: '#00c864',
    settings: [
      { label: 'Two-Factor Authentication', value: false, type: 'toggle' },
      { label: 'Login Notifications', value: true, type: 'toggle' },
      { label: 'Session Timeout', value: '30 minutes', type: 'select' },
    ],
  },
  {
    id: 'appearance',
    title: 'Appearance',
    icon: Palette,
    color: '#00d4aa',
    settings: [
      { label: 'Theme', value: 'Dark', type: 'select' },
      { label: 'Language', value: 'English', type: 'select' },
      { label: 'Date Format', value: 'DD/MM/YYYY', type: 'select' },
      { label: 'Compact View', value: false, type: 'toggle' },
    ],
  },
];

function ToggleSwitch({ enabled }: { enabled: boolean }) {
  const [on, setOn] = useState(enabled);

  return (
    <button
      onClick={() => setOn(!on)}
      className="relative w-10 h-6 rounded-full transition-all duration-300 flex-shrink-0"
      style={{ background: on ? 'rgba(0,212,170,0.5)' : 'rgba(255,255,255,0.1)' }}
    >
      <motion.div
        animate={{ x: on ? 16 : 2 }}
        transition={{ duration: 0.2 }}
        className="absolute top-1 w-4 h-4 rounded-full"
        style={{ background: on ? '#00d4aa' : '#8899bb' }}
      />
    </button>
  );
}

import { useState } from 'react';

export default function Settings() {
  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center gap-3 mb-2">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center font-bold text-xl"
          style={{ background: 'linear-gradient(135deg, #00d4aa, #1e88e5)', color: '#060b18' }}>
          NB
        </div>
        <div>
          <div className="font-bold text-lg" style={{ color: '#f0f4ff', fontFamily: 'Space Grotesk' }}>N. Balakrishna</div>
          <div style={{ fontSize: 13, color: '#8899bb' }}>Member of Parliament • Guntur Constituency</div>
          <div className="flex items-center gap-1.5 mt-1">
            <div className="w-1.5 h-1.5 rounded-full" style={{ background: '#00d4aa' }} />
            <span style={{ fontSize: 11, color: '#00d4aa' }}>Active Session</span>
          </div>
        </div>
      </div>

      {sections.map((section, si) => {
        const Icon = section.icon;
        return (
          <motion.div
            key={section.id}
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: si * 0.1 }}
            className="glass-card rounded-2xl overflow-hidden"
          >
            <div className="flex items-center gap-3 p-4"
              style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', background: 'rgba(255,255,255,0.02)' }}>
              <div className="w-8 h-8 rounded-xl flex items-center justify-center"
                style={{ background: section.color + '20' }}>
                <Icon size={16} style={{ color: section.color }} />
              </div>
              <h3 className="font-semibold" style={{ color: '#f0f4ff', fontSize: 14, fontFamily: 'Space Grotesk' }}>
                {section.title}
              </h3>
            </div>
            <div className="p-2">
              {section.settings.map((setting, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between px-4 py-3 rounded-xl"
                  style={{ transition: 'background 0.2s' }}
                  onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,255,255,0.03)')}
                  onMouseLeave={e => (e.currentTarget.style.background = 'transparent')}
                >
                  <span style={{ fontSize: 13, color: '#f0f4ff' }}>{setting.label}</span>
                  {setting.type === 'toggle' ? (
                    <ToggleSwitch enabled={setting.value as boolean} />
                  ) : (
                    <div className="flex items-center gap-2">
                      <span style={{ fontSize: 13, color: '#8899bb' }}>{setting.value as string}</span>
                      <ChevronRight size={14} style={{ color: '#8899bb' }} />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        );
      })}

      <motion.div
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
        className="glass-card rounded-2xl p-4"
      >
        <h3 className="font-semibold mb-3" style={{ color: '#f0f4ff', fontSize: 14, fontFamily: 'Space Grotesk' }}>
          System Info
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {[
            { label: 'Version', value: 'NETHRA v2.0.0', icon: Zap },
            { label: 'Database', value: 'Supabase PostgreSQL', icon: Database },
            { label: 'Security', value: 'AES-256 Encrypted', icon: Key },
            { label: 'Region', value: 'ap-south-1 (India)', icon: Globe },
          ].map((item, i) => {
            const Icon = item.icon;
            return (
              <div key={i} className="flex items-center gap-3 p-3 rounded-xl"
                style={{ background: 'rgba(255,255,255,0.03)' }}>
                <Icon size={14} style={{ color: '#8899bb' }} />
                <div>
                  <div style={{ fontSize: 11, color: '#8899bb' }}>{item.label}</div>
                  <div style={{ fontSize: 12, fontWeight: 500, color: '#f0f4ff' }}>{item.value}</div>
                </div>
              </div>
            );
          })}
        </div>
      </motion.div>

      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.6 }}
      >
        <button className="w-full py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
          style={{
            background: 'rgba(255,85,85,0.08)', border: '1px solid rgba(255,85,85,0.2)',
            color: '#ff5555', fontSize: 14, fontWeight: 600, cursor: 'pointer'
          }}
          onMouseEnter={e => (e.currentTarget.style.background = 'rgba(255,85,85,0.15)')}
          onMouseLeave={e => (e.currentTarget.style.background = 'rgba(255,85,85,0.08)')}
        >
          <LogOut size={16} /> Sign Out
        </button>
      </motion.div>
    </div>
  );
}
