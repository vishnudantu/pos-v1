import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from './supabase';

export interface UserRole {
  id: string;
  user_id: string;
  role: 'super_admin' | 'politician_admin' | 'staff';
  politician_id: string | null;
}

export interface PoliticianProfile {
  id: string;
  full_name: string;
  display_name: string | null;
  photo_url: string | null;
  party: string | null;
  designation: string | null;
  constituency_name: string | null;
  state: string | null;
  slug: string | null;
  subscription_status: string | null;
  color_primary: string | null;
  color_secondary: string | null;
  is_active: boolean;
}

interface AuthContextType {
  user: User | null;
  session: Session | null;
  userRole: UserRole | null;
  activePolitician: PoliticianProfile | null;
  allPoliticians: PoliticianProfile[];
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  setActivePolitician: (politician: PoliticianProfile) => void;
  refreshPoliticians: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [activePolitician, setActivePoliticianState] = useState<PoliticianProfile | null>(null);
  const [allPoliticians, setAllPoliticians] = useState<PoliticianProfile[]>([]);
  const [loading, setLoading] = useState(true);

  async function fetchUserRole(userId: string): Promise<UserRole | null> {
    const { data, error } = await supabase
      .from('user_roles')
      .select('*')
      .eq('user_id', userId)
      .maybeSingle();
    if (error || !data) {
      const { data: bootstrapResult } = await supabase.rpc('bootstrap_super_admin', { p_user_id: userId });
      if (bootstrapResult?.success) {
        const { data: retryData } = await supabase
          .from('user_roles')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle();
        return retryData as UserRole | null;
      }
      return null;
    }
    return data as UserRole;
  }

  async function fetchPoliticians(role: UserRole): Promise<PoliticianProfile[]> {
    const { data, error } = await supabase
      .from('politician_profiles')
      .select('id, full_name, display_name, photo_url, party, designation, constituency_name, state, slug, subscription_status, color_primary, color_secondary, is_active')
      .order('full_name');
    if (error || !data) return [];
    return data as PoliticianProfile[];
  }

  async function loadUserData(sessionUser: User) {
    const role = await fetchUserRole(sessionUser.id);
    setUserRole(role);

    if (role) {
      const politicians = await fetchPoliticians(role);
      setAllPoliticians(politicians);

      const stored = localStorage.getItem('nethra_active_politician');
      if (stored && role.role === 'super_admin') {
        const found = politicians.find(p => p.id === stored);
        setActivePoliticianState(found || politicians[0] || null);
      } else if (role.politician_id) {
        const mine = politicians.find(p => p.id === role.politician_id);
        setActivePoliticianState(mine || null);
      } else {
        setActivePoliticianState(politicians[0] || null);
      }
    }
  }

  async function refreshPoliticians() {
    if (!userRole) return;
    const politicians = await fetchPoliticians(userRole);
    setAllPoliticians(politicians);
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        loadUserData(session.user).finally(() => setLoading(false));
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((event, session) => {
      setSession(session);
      setUser(session?.user ?? null);
      if (session?.user) {
        (async () => {
          await loadUserData(session.user);
          setLoading(false);
        })();
      } else {
        setUserRole(null);
        setActivePoliticianState(null);
        setAllPoliticians([]);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  async function signIn(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error as Error | null };
  }

  async function signOut() {
    localStorage.removeItem('nethra_active_politician');
    await supabase.auth.signOut();
  }

  function setActivePolitician(politician: PoliticianProfile) {
    setActivePoliticianState(politician);
    localStorage.setItem('nethra_active_politician', politician.id);
  }

  return (
    <AuthContext.Provider value={{
      user, session, userRole, activePolitician, allPoliticians,
      loading, signIn, signOut, setActivePolitician, refreshPoliticians
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
