INSERT IGNORE INTO rss_feeds (politician_id, feed_name, feed_url, feed_type, language, is_active)
SELECT pp.id, f.feed_name, f.feed_url, f.feed_type, f.language, 1
FROM politician_profiles pp
CROSS JOIN (
  SELECT 'The Hindu - National' as feed_name, 'https://www.thehindu.com/news/national/?service=rss' as feed_url, 'national' as feed_type, 'english' as language UNION ALL
  SELECT 'Indian Express', 'https://indianexpress.com/feed/', 'national', 'english' UNION ALL
  SELECT 'Times of India', 'https://timesofindia.indiatimes.com/rssfeedstopstories.cms', 'national', 'english' UNION ALL
  SELECT 'NDTV News', 'https://feeds.feedburner.com/ndtvnews-latest', 'national', 'english' UNION ALL
  SELECT 'Deccan Chronicle', 'https://www.deccanchronicle.com/rss.xml', 'national', 'english' UNION ALL
  SELECT 'India Today', 'https://www.indiatoday.in/rss/home', 'national', 'english' UNION ALL
  SELECT 'The Wire', 'https://thewire.in/rss', 'national', 'english' UNION ALL
  SELECT 'Scroll.in', 'https://scroll.in/rss', 'national', 'english' UNION ALL
  SELECT 'News18 India', 'https://www.news18.com/rss/india.xml', 'national', 'english' UNION ALL
  SELECT 'Hindustan Times', 'https://www.hindustantimes.com/feeds/rss/india-news/rssfeed.xml', 'national', 'english' UNION ALL
  SELECT 'Live Law', 'https://www.livelaw.in/rss', 'national', 'english' UNION ALL
  SELECT 'Business Standard', 'https://www.business-standard.com/rss/latest.rss', 'national', 'english' UNION ALL
  SELECT 'The Print', 'https://theprint.in/feed/', 'national', 'english' UNION ALL
  SELECT 'The Hindu Opinion', 'https://www.thehindu.com/opinion/?service=rss', 'national', 'english' UNION ALL
  SELECT 'Indian Express Opinion', 'https://indianexpress.com/section/opinion/feed/', 'national', 'english' UNION ALL
  SELECT 'AndhraWatch', 'https://andhrawatch.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'NTV Telugu', 'https://ntvtelugu.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'Visala Andhra', 'https://visalaandhra.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'OkTelugu', 'https://oktelugu.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Bulletin', 'https://www.telugubulletin.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Stop', 'https://telugustop.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'V6 Velugu', 'https://www.v6velugu.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Rajyam', 'https://telugurajyam.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'Adya News Telugu', 'https://www.adya.news/telugu/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Namasthe Telangana', 'https://www.ntnews.com/news/feed', 'state', 'telugu' UNION ALL
  SELECT 'Telugu360', 'https://www.telugu360.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Journalist', 'https://telugujournalist.com/category/news/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Vaartha', 'https://vaartha.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Gulte Telugu', 'https://telugu.gulte.com/feed', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Mirchi', 'https://www.telugumirchi.com/telugu/feed', 'state', 'telugu' UNION ALL
  SELECT 'Prajatantra News', 'https://www.prajatantranews.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'TeluguISM', 'https://teluguism.com/category/news/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Post', 'https://www.telugupost.com/latest-news/feed', 'state', 'telugu' UNION ALL
  SELECT '10 TV Latest', 'https://10tv.in/latest/feed', 'state', 'telugu' UNION ALL
  SELECT 'Manalokam', 'https://manalokam.com/news/feed', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Bullet', 'https://telugu.telugubullet.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Andhrajyothi RSS', 'https://www.andhrajyothy.com/rss/feed.xml', 'state', 'telugu' UNION ALL
  SELECT 'Sakshi - Telugu', 'https://www.sakshi.com/rss-feeds/all', 'state', 'telugu' UNION ALL
  SELECT 'Eenadu', 'https://www.eenadu.net/rssfeed.php', 'state', 'telugu' UNION ALL
  SELECT 'ABP Live Telugu', 'https://telugu.abplive.com/rss', 'state', 'telugu' UNION ALL
  SELECT 'TV9 Telugu', 'https://www.tv9telugu.com/rss', 'state', 'telugu' UNION ALL
  SELECT 'Mana Telangana', 'https://www.manatelangana.news/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Nava Telangana', 'https://navatelangana.com/feed/', 'state', 'telugu' UNION ALL
  SELECT 'Telugu Global', 'https://www.teluguglobal.com/news/feed', 'state', 'telugu'
) f;
