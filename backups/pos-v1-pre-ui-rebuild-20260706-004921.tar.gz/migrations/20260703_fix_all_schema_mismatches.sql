DELIMITER $$

DROP PROCEDURE IF EXISTS AddColIfNotExists$$

CREATE PROCEDURE AddColIfNotExists(
  IN p_table VARCHAR(255),
  IN p_column VARCHAR(255),
  IN p_definition VARCHAR(1000)
)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE()
      AND table_name = p_table
      AND column_name = p_column
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END IF;
END$$

DELIMITER ;

-- Grievances
CALL AddColIfNotExists('grievances', 'ticket_number', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('grievances', 'contact', 'VARCHAR(100) DEFAULT NULL');

-- Events
CALL AddColIfNotExists('events', 'attendees', 'JSON DEFAULT NULL');
CALL AddColIfNotExists('events', 'notes', 'TEXT DEFAULT NULL');

-- Team Members
CALL AddColIfNotExists('team_members', 'status', "VARCHAR(50) DEFAULT 'active'");
CALL AddColIfNotExists('team_members', 'joining_date', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('team_members', 'avatar_url', 'VARCHAR(500) DEFAULT NULL');
CALL AddColIfNotExists('team_members', 'skills', 'JSON DEFAULT NULL');
CALL AddColIfNotExists('team_members', 'notes', 'TEXT DEFAULT NULL');

-- Projects
CALL AddColIfNotExists('projects', 'category', 'VARCHAR(100) DEFAULT NULL');
CALL AddColIfNotExists('projects', 'start_date', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('projects', 'actual_completion', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('projects', 'beneficiaries', 'JSON DEFAULT NULL');
CALL AddColIfNotExists('projects', 'scheme', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('projects', 'notes', 'TEXT DEFAULT NULL');

-- Media Mentions
CALL AddColIfNotExists('media_mentions', 'language', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('media_mentions', 'tags', 'JSON DEFAULT NULL');
CALL AddColIfNotExists('media_mentions', 'is_read', 'TINYINT(1) DEFAULT 0');
CALL AddColIfNotExists('media_mentions', 'reach', 'INT DEFAULT NULL');

-- Finances
CALL AddColIfNotExists('finances', 'date', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('finances', 'payment_mode', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('finances', 'reference_number', 'VARCHAR(100) DEFAULT NULL');
CALL AddColIfNotExists('finances', 'project_id', 'INT DEFAULT NULL');
CALL AddColIfNotExists('finances', 'status', "VARCHAR(50) DEFAULT 'pending'");
CALL AddColIfNotExists('finances', 'notes', 'TEXT DEFAULT NULL');

-- Communications
CALL AddColIfNotExists('communications', 'comm_type', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('communications', 'recipient_group', 'VARCHAR(100) DEFAULT NULL');
CALL AddColIfNotExists('communications', 'scheduled_at', 'DATETIME DEFAULT NULL');
CALL AddColIfNotExists('communications', 'open_rate', 'DECIMAL(5,2) DEFAULT NULL');

-- Documents
CALL AddColIfNotExists('documents', 'doc_type', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('documents', 'file_name', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('documents', 'description', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('documents', 'tags', 'JSON DEFAULT NULL');
CALL AddColIfNotExists('documents', 'is_confidential', 'TINYINT(1) DEFAULT 0');

-- Voters
CALL AddColIfNotExists('voters', 'address', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('voters', 'party_affiliation', 'VARCHAR(100) DEFAULT NULL');
CALL AddColIfNotExists('voters', 'support_level', 'INT DEFAULT NULL');
CALL AddColIfNotExists('voters', 'is_active', 'TINYINT(1) DEFAULT 1');
CALL AddColIfNotExists('voters', 'tags', 'JSON DEFAULT NULL');

-- Sentiment Scores
CALL AddColIfNotExists('sentiment_scores', 'issue_breakdown', 'JSON DEFAULT NULL');

-- Opposition Intelligence
CALL AddColIfNotExists('opposition_intelligence', 'opponent_party', 'VARCHAR(100) DEFAULT NULL');
CALL AddColIfNotExists('opposition_intelligence', 'opponent_constituency', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('opposition_intelligence', 'source', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('opposition_intelligence', 'sentiment_toward_us', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('opposition_intelligence', 'ai_analysis', 'TEXT DEFAULT NULL');

-- Voice Reports
CALL AddColIfNotExists('voice_reports', 'attachments', 'JSON DEFAULT NULL');

-- AI Generated Content
CALL AddColIfNotExists('ai_generated_content', 'tags', 'JSON DEFAULT NULL');

-- WhatsApp Intelligence
CALL AddColIfNotExists('whatsapp_intelligence', 'transcription', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('whatsapp_intelligence', 'viral_count', 'INT DEFAULT 0');
CALL AddColIfNotExists('whatsapp_intelligence', 'routed_to', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('whatsapp_intelligence', 'action_taken', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('whatsapp_intelligence', 'processed_at', 'DATETIME DEFAULT NULL');

-- Visit Plans (missing table)
CREATE TABLE IF NOT EXISTS visit_plans (
  id INT AUTO_INCREMENT PRIMARY KEY,
  politician_id INT DEFAULT NULL,
  plan_name VARCHAR(255) DEFAULT NULL,
  visit_date DATE DEFAULT NULL,
  location VARCHAR(255) DEFAULT NULL,
  mandal VARCHAR(255) DEFAULT NULL,
  village VARCHAR(255) DEFAULT NULL,
  objective TEXT DEFAULT NULL,
  status VARCHAR(50) DEFAULT 'Planned',
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician (politician_id)
);

-- Booths
CALL AddColIfNotExists('booths', 'booth_name', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('booths', 'location', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('booths', 'total_voters', 'INT DEFAULT NULL');
CALL AddColIfNotExists('booths', 'expected_turnout', 'INT DEFAULT NULL');
CALL AddColIfNotExists('booths', 'historical_vote_percentage', 'DECIMAL(5,2) DEFAULT NULL');
CALL AddColIfNotExists('booths', 'coordinates', 'VARCHAR(255) DEFAULT NULL');

-- Predictive Alerts
CALL AddColIfNotExists('predictive_alerts', 'probability', 'DECIMAL(5,2) DEFAULT NULL');
CALL AddColIfNotExists('predictive_alerts', 'recommended_action', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('predictive_alerts', 'timeframe_days', 'INT DEFAULT NULL');

-- Agent Tasks
CALL AddColIfNotExists('agent_tasks', 'description', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('agent_tasks', 'assigned_to', 'INT DEFAULT NULL');

-- Deepfake Incidents
CALL AddColIfNotExists('deepfake_incidents', 'confidence', 'DECIMAL(5,2) DEFAULT NULL');
CALL AddColIfNotExists('deepfake_incidents', 'response_plan', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('deepfake_incidents', 'notes', 'TEXT DEFAULT NULL');

-- Relationships
CALL AddColIfNotExists('relationships', 'influence_score', 'INT DEFAULT NULL');
CALL AddColIfNotExists('relationships', 'alignment', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('relationships', 'last_contact_at', 'DATETIME DEFAULT NULL');

-- Economic Indicators
CALL AddColIfNotExists('economic_indicators', 'unit', 'VARCHAR(50) DEFAULT NULL');
CALL AddColIfNotExists('economic_indicators', 'source', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('economic_indicators', 'notes', 'TEXT DEFAULT NULL');

-- Citizen Service Requests
CALL AddColIfNotExists('citizen_service_requests', 'source', 'VARCHAR(255) DEFAULT NULL');

-- Election Updates
CALL AddColIfNotExists('election_updates', 'booth_id', 'INT DEFAULT NULL');
CALL AddColIfNotExists('election_updates', 'reported_at', 'DATETIME DEFAULT NULL');

-- Finance Compliance Reports
CALL AddColIfNotExists('finance_compliance_reports', 'summary', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('finance_compliance_reports', 'alerts', 'JSON DEFAULT NULL');

-- Party Integrations
CALL AddColIfNotExists('party_integrations', 'status', "VARCHAR(50) DEFAULT 'active'");
CALL AddColIfNotExists('party_integrations', 'last_sync_at', 'DATETIME DEFAULT NULL');
CALL AddColIfNotExists('party_integrations', 'notes', 'TEXT DEFAULT NULL');

-- Digital Twin Runs
CALL AddColIfNotExists('digital_twin_runs', 'input_summary', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('digital_twin_runs', 'output_summary', 'TEXT DEFAULT NULL');

-- Promises
CALL AddColIfNotExists('promises', 'made_at', 'DATETIME DEFAULT NULL');
CALL AddColIfNotExists('promises', 'location', 'VARCHAR(255) DEFAULT NULL');
CALL AddColIfNotExists('promises', 'linked_project_id', 'INT DEFAULT NULL');
CALL AddColIfNotExists('promises', 'deadline', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('promises', 'completion_date', 'DATE DEFAULT NULL');
CALL AddColIfNotExists('promises', 'notes', 'TEXT DEFAULT NULL');
CALL AddColIfNotExists('promises', 'source', 'VARCHAR(255) DEFAULT NULL');

-- Darshan pilgrims (ensure exists)
CREATE TABLE IF NOT EXISTS darshan_pilgrims (
  id INT AUTO_INCREMENT PRIMARY KEY,
  politician_id INT DEFAULT NULL,
  pilgrim_name VARCHAR(255) DEFAULT NULL,
  pilgrim_contact VARCHAR(50) DEFAULT NULL,
  age INT DEFAULT NULL,
  gender VARCHAR(20) DEFAULT NULL,
  id_proof VARCHAR(100) DEFAULT NULL,
  id_number VARCHAR(100) DEFAULT NULL,
  darshan_date DATE DEFAULT NULL,
  status VARCHAR(50) DEFAULT 'Pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician (politician_id)
);
