CREATE TABLE IF NOT EXISTS darshans (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  temple_name VARCHAR(255) DEFAULT NULL,
  darshan_date DATE DEFAULT NULL,
  status VARCHAR(50) DEFAULT 'Requested',
  pilgrim_name VARCHAR(255) DEFAULT NULL,
  pilgrim_contact VARCHAR(50) DEFAULT NULL,
  location VARCHAR(255) DEFAULT NULL,
  group_size INT DEFAULT NULL,
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician (politician_id),
  KEY idx_date (darshan_date),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
