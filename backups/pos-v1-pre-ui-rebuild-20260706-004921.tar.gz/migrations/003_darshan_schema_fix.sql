-- Backup legacy tables
CREATE TABLE IF NOT EXISTS darshan_bookings_legacy LIKE darshan_bookings;
INSERT INTO darshan_bookings_legacy SELECT * FROM darshan_bookings;

CREATE TABLE IF NOT EXISTS darshan_pilgrims_legacy LIKE darshan_pilgrims;
INSERT INTO darshan_pilgrims_legacy SELECT * FROM darshan_pilgrims;

-- New darshan_bookings schema
DROP TABLE IF EXISTS darshan_bookings;
CREATE TABLE darshan_bookings (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  booking_ref VARCHAR(50) NOT NULL UNIQUE,
  letter_date DATE NOT NULL,
  visit_date DATE NOT NULL,
  total_pilgrims INT NOT NULL DEFAULT 0,
  status VARCHAR(50) NOT NULL DEFAULT 'pending',
  created_by INT DEFAULT NULL,
  approved_by INT DEFAULT NULL,
  approved_at DATETIME DEFAULT NULL,
  contact_person VARCHAR(255) DEFAULT NULL,
  contact_phone VARCHAR(50) DEFAULT NULL,
  pickup_point VARCHAR(255) DEFAULT NULL,
  shrine_contacts VARCHAR(255) DEFAULT NULL,
  sms_sent TINYINT(1) NOT NULL DEFAULT 0,
  notes TEXT DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician_date (politician_id, letter_date),
  KEY idx_booking_ref (booking_ref),
  KEY idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- New darshan_pilgrims schema
DROP TABLE IF EXISTS darshan_pilgrims;
CREATE TABLE darshan_pilgrims (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  politician_id INT NOT NULL,
  full_name VARCHAR(255) NOT NULL,
  phone VARCHAR(20) NOT NULL,
  aadhaar_hash VARCHAR(255) NOT NULL,
  aadhaar_last4 VARCHAR(4) DEFAULT NULL,
  age INT DEFAULT NULL,
  gender VARCHAR(20) DEFAULT NULL,
  darshan_type VARCHAR(100) NOT NULL DEFAULT 'SSD Darshan',
  address VARCHAR(255) DEFAULT NULL,
  visit_date DATE DEFAULT NULL,
  validation_status VARCHAR(50) DEFAULT 'valid',
  mandal VARCHAR(255) DEFAULT NULL,
  village VARCHAR(255) DEFAULT NULL,
  town VARCHAR(255) DEFAULT NULL,
  assembly_segment VARCHAR(255) DEFAULT NULL,
  voter_id VARCHAR(100) DEFAULT NULL,
  party_connection VARCHAR(100) DEFAULT 'general_public',
  referral_name VARCHAR(255) DEFAULT NULL,
  is_constituency_voter TINYINT(1) DEFAULT NULL,
  occupation VARCHAR(255) DEFAULT NULL,
  notes TEXT DEFAULT NULL,
  sms_sent TINYINT(1) NOT NULL DEFAULT 0,
  sms_sent_at DATETIME DEFAULT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_booking (booking_id),
  KEY idx_politician (politician_id),
  KEY idx_aadhaar_hash (aadhaar_hash),
  KEY idx_phone (phone),
  KEY idx_visit_date (visit_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Quota table
CREATE TABLE IF NOT EXISTS darshan_daily_quota (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  letter_date DATE NOT NULL,
  pilgrims_booked INT NOT NULL DEFAULT 0,
  max_pilgrims INT NOT NULL DEFAULT 6,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_politician_date (politician_id, letter_date),
  KEY idx_date (letter_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
