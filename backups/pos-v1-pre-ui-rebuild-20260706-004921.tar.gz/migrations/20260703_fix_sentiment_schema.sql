ALTER TABLE media_mentions
ADD COLUMN source_type VARCHAR(50) DEFAULT NULL AFTER source,
ADD INDEX idx_source_type (source_type);

ALTER TABLE whatsapp_intelligence
ADD COLUMN received_at DATETIME DEFAULT NULL AFTER created_at,
ADD INDEX idx_received_at (received_at);

ALTER TABLE sentiment_scores
ADD COLUMN news_score INT DEFAULT NULL AFTER overall_score,
ADD COLUMN social_score INT DEFAULT NULL AFTER news_score,
ADD COLUMN whatsapp_score INT DEFAULT NULL AFTER social_score,
ADD COLUMN grievance_score INT DEFAULT NULL AFTER whatsapp_score,
ADD COLUMN ground_score INT DEFAULT NULL AFTER grievance_score,
ADD COLUMN channel_breakdown JSON DEFAULT NULL AFTER ground_score;

UPDATE media_mentions SET source_type = 'News' WHERE source_type IS NULL;
UPDATE whatsapp_intelligence SET received_at = created_at WHERE received_at IS NULL;
