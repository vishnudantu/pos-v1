CREATE TABLE IF NOT EXISTS ai_training_rules (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  rule_type ENUM('identity','style','avoid','example','template') NOT NULL,
  title VARCHAR(255) DEFAULT NULL,
  content TEXT NOT NULL,
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician_rule (politician_id, rule_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
