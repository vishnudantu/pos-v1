CREATE TABLE IF NOT EXISTS rss_feeds (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  feed_name VARCHAR(255) NOT NULL,
  feed_url VARCHAR(1000) NOT NULL,
  feed_type ENUM('national','state','local','international') NOT NULL DEFAULT 'national',
  language VARCHAR(50) DEFAULT 'english',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  last_scanned_at TIMESTAMP NULL,
  last_status VARCHAR(50) DEFAULT 'pending',
  last_error TEXT,
  items_fetched INT DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician (politician_id),
  KEY idx_type (feed_type),
  KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
