CREATE TABLE IF NOT EXISTS keywords (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  politician_id INT NOT NULL,
  keyword VARCHAR(255) NOT NULL,
  keyword_type VARCHAR(50) NOT NULL DEFAULT 'politician',
  is_active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  KEY idx_politician (politician_id),
  KEY idx_type (keyword_type),
  KEY idx_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
