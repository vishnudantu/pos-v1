-- Version-safe column additions: checks information_schema before adding each column
-- Run with: mysql -u pos_user -p pos_db < apps/api/migrations/20260703_save_fix_missing_columns.sql

DELIMITER $$

DROP PROCEDURE IF EXISTS add_col_if_missing$$

CREATE PROCEDURE add_col_if_missing(
  IN p_table VARCHAR(64),
  IN p_column VARCHAR(64),
  IN p_definition VARCHAR(255)
)
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = DATABASE()
      AND table_name = p_table
      AND column_name = p_column
  ) THEN
    SET @sql = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
    PREPARE stmt FROM @sql;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    SELECT CONCAT('Added ', p_column, ' to ', p_table) AS status;
  ELSE
    SELECT CONCAT(p_column, ' already exists in ', p_table) AS status;
  END IF;
END$$

DELIMITER ;

CALL add_col_if_missing('events', 'event_date', 'DATETIME DEFAULT NULL');
CALL add_col_if_missing('citizen_engagements', 'event_date', 'DATETIME DEFAULT NULL');
CALL add_col_if_missing('constituency_profiles', 'urban_population_pct', 'DECIMAL(5,2) NULL');
CALL add_col_if_missing('constituency_profiles', 'rural_population_pct', 'DECIMAL(5,2) NULL');
CALL add_col_if_missing('constituency_profiles', 'key_facts', 'TEXT NULL');
CALL add_col_if_missing('constituency_profiles', 'key_industries', 'TEXT NULL');
CALL add_col_if_missing('constituency_profiles', 'revenue_divisions', 'TEXT NULL');
CALL add_col_if_missing('constituency_profiles', 'assembly_segments', 'TEXT NULL');
CALL add_col_if_missing('constituency_profiles', 'notes', 'TEXT NULL');

DROP PROCEDURE IF EXISTS add_col_if_missing;
